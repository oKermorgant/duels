// generated from snake.yaml -- editing this file by hand is not recommended
#ifndef SNAKE_MSG_H
#define SNAKE_MSG_H
#include <sstream>
#include <duels/game_state.h>
#include <duels/utils/pose2d.h>
#include <duels/utils/vector2d.h>

namespace duels {
namespace snake {

// utility structures
struct Snake
{
  duels::Pose2D head;
  std::vector<duels::Vector2D<int>> body;
  inline bool operator==(const Snake &other) const
  {
    return head == other.head && body == other.body;
  }
  inline friend std::ostream& operator<<(std::ostream& ss, const Snake &snake)
  {
    ss << "{";
    ss << "head: " << snake.head << ',';
    ss << "body: " << snake.body << "}";
    return ss;
  }
};


// core game messages

struct InitDisplay
{
  duels::Pose2D snake1;
  duels::Pose2D snake2;
  duels::Vector2D<int> apples;
 
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    ss << "\nsnake1: " << snake1;
    ss << "\nsnake2: " << snake2;
    ss << "\napples: " << apples;
    return ss.str();
  }
};

struct Input
{
  enum class Action{TURN_LEFT,TURN_RIGHT,MOVE};  Action action;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "action: " << action;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    action = node["action"].as<Action>();
  }
};

struct Feedback
{
  Snake pose;
  Snake pose_other;
  std::vector<duels::Vector2D<int>> apple;
  State __state;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "pose: " << pose;
    ss << "\npose_other: " << pose_other;
    ss << "\napple: " << apple;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    pose = node["pose"].as<Snake>();
    pose_other = node["pose_other"].as<Snake>();
    apple = node["apple"].as<std::vector<duels::Vector2D<int>>>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  Snake snake1;
  Snake snake2;
  std::vector<duels::Vector2D<int>> apples;
  int score1;
  int score2;
 
  std::string serialize(State state) const 
  {
    std::stringstream ss;
    ss << "state: " << state;
    ss << "\nsnake1: " << snake1;
    ss << "\nsnake2: " << snake2;
    ss << "\napples: " << apples;
    ss << "\nscore1: " << score1;
    ss << "\nscore2: " << score2;
    return ss.str();
  }
};

}}

namespace YAML
{
template<>
struct convert<duels::snake::Snake> 
{
  static bool decode(Node const& node, duels::snake::Snake & rhs)
  {
    rhs.head = node["head"].as<duels::Pose2D>();
    rhs.body = node["body"].as<std::vector<duels::Vector2D<int>>>();
    return true;
  }
};
}

#endif