#include <duels/connect4/msg.h>

using namespace duels::connect4;

// this code is to test parts of your code if needed

int main(int argc, char** argv)
{



}
