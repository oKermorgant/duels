#include <duels/gorillas/msg.h>

using namespace duels::gorillas;

// this code is to test parts of your code if needed

int main(int argc, char** argv)
{



}
