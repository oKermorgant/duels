#include <duels/snake/msg.h>

using namespace duels::snake;

// this code is to test parts of your code if needed

int main(int argc, char** argv)
{



}
