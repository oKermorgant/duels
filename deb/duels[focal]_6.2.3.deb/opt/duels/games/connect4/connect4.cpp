#include <duels/connect4/game.h>
#include <duels/connect4/connect4AI.h>

using namespace duels::connect4;

int main(int argc, char** argv)
{
  
  Game game(argc, argv, "your name", 0);    // to play as player 1 against level 0 AI
  //Game game(argc, argv, "your name", -2);    // to play as player 2 against level 2 AI

  Feedback feedback;
  [[maybe_unused]] const auto timeout = game.timeout_ms();

  Connect4AI ai;

  // this loop continues until game over
  while(game.get(feedback))
  {
    const auto move{ai.computeFrom(feedback)};

    game.send(move);
  }
}
