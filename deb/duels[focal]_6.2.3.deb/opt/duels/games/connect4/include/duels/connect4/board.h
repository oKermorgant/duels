#ifndef CONNECT4_BOARD_H
#define CONNECT4_BOARD_H

#include <duels/connect4/msg.h>
#include <array>
#include <optional>

using namespace duels::connect4;
using duels::Result;

class Board
{
public:

  /// TODO negamax interface

  std::vector<short> availableMoves() const;

  void makeMove(short col);

  void cancelMove(short col);

  //  returns the score for a final state, or nothing if non-final
  std::optional<int> finalScore() const;

  // returns the heuristic for non-final states
  int heuristic() const;

public:

  Board();

  // helper functions
  void print() const;

private:

  // you cannot copy this class because of segment pointers
  Board(const Board &other) = delete;

  // dimension of the board
  static constexpr short rows{6};
  static constexpr short cols{7};

  // how will be playing next
  short cur_player = 1;

  // underlying grid, 6x7 with 0's at start
  std::array<std::array<short, cols>, rows> grid{};

  // how many available rows remain free, for each column
  std::array<short, cols> capacity{};

  // all segments of dim. 4
  using Segment = std::array<short*, 4>;
  std::array<Segment,69> segments;

  // returns how many 0, 1 and 2 are in this segment
  inline static std::array<short,3> count(const Segment &seg)
  {
    std::array<short,3> count{};
    for(auto s: seg)
      count[*s]++;
    return count;
  }

  // who is not playing right now (and has just played before)
  inline auto otherPlayer() const
  {
    return 3-cur_player;
  }

  // register a turn
  inline void changePlayer()
  {
    cur_player = otherPlayer();
  }


};

#endif
