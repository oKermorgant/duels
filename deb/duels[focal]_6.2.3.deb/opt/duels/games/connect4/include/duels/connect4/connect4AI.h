#ifndef CONNECT4AI_H
#define CONNECT4AI_H

#include <duels/connect4/msg.h>
#include <duels/connect4/board.h>
#include <duels/algo/minmax.h>

using namespace duels;
using namespace duels::connect4;

class Connect4AI
{
  // underlying board, to be kept up-to-date with the moves
  Board board;

public:

  Input computeFrom(const Feedback &feedback)
  {
    /// TODO register previous move, if any


    // for now pick column 3
    short move = 3;

    /// TODO make a better choice using negamax algorithm


    /// TODO register your move in the board


    // send this move to the game
    return {move};
  }
};



#endif // CONNECT4AI_H
