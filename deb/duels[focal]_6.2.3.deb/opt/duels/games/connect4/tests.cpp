#include <duels/connect4/msg.h>
#include <duels/algo/minmax.h>

using namespace duels::connect4;
using namespace duels;

// this file is to test parts of your code if needed

int main(int argc, char** argv)
{



}
