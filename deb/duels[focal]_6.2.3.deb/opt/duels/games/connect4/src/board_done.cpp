#include <duels/connect4/board.h>
#include <iostream>

Board::Board()
{
  // 6 places in each column at start
  for(auto &c: capacity)
    c = rows;
  // init all valid segments
  auto idx{0};
  const auto addSegment{[this,&idx](short row, short col, short dr, short dc)
      {
        for(int i = 0; i < 4; ++i)
          segments[idx][i] = &(grid[row+i*dr][col+i*dc]);
        idx++;}
  };

  // horizontal
  for(auto row = 0; row < rows; row++)
  {
    for(auto col = 0; col < cols-3; col++)
      addSegment(row, col, 0, 1);
  }

  // vertical
  for(auto row = 0; row < rows-3; row++)
  {
    for(auto col = 0; col < cols; col++)
      addSegment(row, col, 1, 0);
  }

  // left diagonal
  for(auto row = 0; row < rows-3; row++)
  {
    for(auto col = 3; col < cols; col++)
      addSegment(row, col, 1, -1);
  }

  // right diagonal
  for(auto row = 0; row < rows-3; row++)
  {
    for(auto col = 0; col < cols-3; col++)
      addSegment(row, col, 1, 1);
  }

}


void Board::print() const
{
  static const std::string symbols{".12"};
  std::cout << " ";
  for(auto c = 0; c < cols; ++c)
  {
    std::cout << " " << c;
  }
  std::cout << '\n';
  for(auto r = 0; r < rows; ++r)
  {
    std::cout << r;
    for(auto c = 0; c < cols; ++c)
    {
      std::cout << " " << symbols[grid[r][c]];
    }
    std::cout << '\n';
  }
  std::cout << std::endl;
}
