#include <cassert>
#include <duels/connect4/board.h>


// return what columns are available to play
std::vector<short> Board::availableMoves() const
{
  return {};
}

// insert a token in this column
// switch to the other player
// update the capacity of this column
void Board::makeMove(short col)
{


}

// release the last token played in this column
// switch to the other player
// update the capacity of this column
void Board::cancelMove(short col)
{


}


//  returns the score for a final state, or nothing if non-final
std::optional<int> Board::finalScore() const
{

  // returns nothing for now
  return {};
}

// returns the heuristic for non-final states
int Board::heuristic() const
{

  return 0;
}

