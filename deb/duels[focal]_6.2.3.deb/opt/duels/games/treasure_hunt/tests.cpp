#include <duels/treasure_hunt/msg.h>

using namespace duels::treasure_hunt;

// this file is to test parts of your code if needed

int main(int argc, char** argv)
{



}
