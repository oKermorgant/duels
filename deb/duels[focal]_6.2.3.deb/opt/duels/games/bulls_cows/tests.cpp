#include <duels/bulls_cows/msg.h>

using namespace duels::bulls_cows;

// this file is to test parts of your code if needed

int main(int argc, char** argv)
{



}
