#ifndef DUELS_MINMAX_H
#define DUELS_MINMAX_H

#include <duels/game_state.h>
#include <duels/utils/rand_utils.h>
#include <unordered_map>
#include <iostream>

/* This function uses alpha-beta negamax algorithm for a given game class
 *
 * required interface:
 * vector<Move> game.availableMoves() for the feasible moves from this state
 * game.makeMove(Move)
 * game.cancelMove(Move)
 * Numeric game.heuristic() for the estimated score of a non-final state
 * optional<Numeric> game.finalScore() for the score of a final state, if it is final
 *
 * optional interface
 * string game.hash(int depth) for a unique ID of a given state at a given depth, used for caching
 */

namespace duels
{

template <class Game>
struct HasHash
{
  template <typename C> static constexpr bool hasHash(...) {return false;}
  template <typename C> static constexpr decltype(&C::hash, bool()) hasHash(int /* unused */)
  {return true;}
  static constexpr bool value = hasHash<Game>(int());
};

namespace negamax_impl
{
/**
  *  @brief This function is called in a recursive way and returns the heuristic at a given depth > 0
 **/
template<class Game,
         typename Numeric = decltype(std::declval<Game>().heuristic())>
Numeric negamax(Game &game, uint max_depth, uint depth,
                Numeric alpha, Numeric beta,
                std::unordered_map<std::string, Numeric> &cache)
{
  std::string hash;
  if constexpr(HasHash<Game>::value)
  {
    hash = game.hash(depth);
    if(const auto heur = cache.find(hash);
        heur != cache.end())
      return heur->second;
  }

  // check for leaf state
  auto score = game.finalScore();

  Numeric heur{};
  if(score.has_value())
  {
    // adapt final heuristic to current depth
    heur = score.value() + (max_depth-depth)*(heur < 0 ? -1 : 1);
  }
  else if(depth == max_depth)
  {
    // use heuristic if end of recursion
    heur = game.heuristic() + max_depth*(heur < 0 ? -1 : 1);
  }
  else
  {
    heur = std::numeric_limits<Numeric>::min()/2;
    // continue with next moves
    for(auto move: game.availableMoves())
    {
      game.makeMove(move);
      heur = std::max(heur, -negamax(game, max_depth, depth+1, -beta, -alpha, cache));
      game.cancelMove(move);
      if(heur >= beta)
        break;
      if(heur > alpha)
        alpha = heur;
    }
  }
  if constexpr(HasHash<Game>::value)
    cache[hash] = heur;
  return heur;
}
}

/**
  *  @brief Root function to solve game with NegaMax at given depth
  *  @return The (possibly several) moves having the best evaluation
 **/
template<class Game,
         typename Numeric = decltype(std::declval<Game>().heuristic()),
         typename Move = std::remove_reference_t<decltype(std::declval<Game>().availableMoves()[0])>>
std::vector<Move> negamax(Game &game, uint max_depth, bool show_scores = false)
{
  std::unordered_map<std::string, Numeric> cache;
  const auto moves{game.availableMoves()};
  std::vector<Move> choices;
  choices.reserve(moves.size());
  auto alpha{std::numeric_limits<Numeric>::min()/2};
  auto beta{std::numeric_limits<Numeric>::max()/2};
  auto best{std::numeric_limits<Numeric>::min()/2};
  for(const auto move: moves)
  {
    game.makeMove(move);
    const auto score = -negamax_impl::negamax(game, max_depth, 1, -beta, -alpha, cache);
    game.cancelMove(move);
    if(score > best)
    {
      best = score;
      choices = {move};
    }
    else if(score == best)
      choices.push_back(move);
    if(show_scores)
      std::cout << "move " << move << " -> " << score << '\n';
  }
  // return any of the best choices
  const auto move{choices[fastrand(choices.size())]};
  if(show_scores)
  {
    std::cout << "Best score " << best << " for move";
    if(choices.size() > 1)
      std::cout << 's';
    for(auto &m: choices)
      std::cout << ' ' << m;
    std::cout << "\n -> picking " << move << std::endl;
  }
  return choices;
}



} // namespace duels

#endif
