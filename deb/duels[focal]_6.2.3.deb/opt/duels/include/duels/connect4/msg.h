// generated from connect4.yaml -- editing this file by hand is not recommended
#ifndef CONNECT4_MSG_H
#define CONNECT4_MSG_H
#include <sstream>
#include <duels/game_state.h>

namespace duels {
namespace connect4 {

struct InitDisplay
{
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    return ss.str();
  }
};

struct Input
{
  short column;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "column: " << column;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    column = node["column"].as<short>();
  }
};

struct Feedback
{
  short column;
  State __state;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "column: " << column;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    column = node["column"].as<short>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  short column;
  short row;
 
  std::string serialize(State state) const 
  {
    std::stringstream ss;
    ss << "state: " << state;
    ss << "\ncolumn: " << column;
    ss << "\nrow: " << row;
    return ss.str();
  }
};

}}


#endif