#ifndef BULLS_COWS_NUMBER
#define BULLS_COWS_NUMBER

#include <array>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>

namespace duels
{
namespace bulls_cows
{

static constexpr ushort LENGTH{6};

struct Number
{  
private:
  std::string digits_;
  uint n_;

  inline void update(const std::string &digits)
  {
    digits_ = digits;
    n_ = std::stoi(digits_);
  }

public:

  inline explicit Number() {digits_.reserve(LENGTH);}

  inline explicit Number(int n)
  {
    if(n >= pow(10, LENGTH))
      throw(std::runtime_error("The number is too big"));
    digits_ = std::to_string(n);
    while(digits_.size() != LENGTH)
      digits_ = '0' + digits_;
    n_ = n;
  }

  inline auto value() const {return n_;}
  inline auto digits() const {return digits_;}

  inline bool operator==(const Number &other) const
  {
    return n_ == other.n_;
  }

  inline static std::vector<Number> allNumbers()
  {
   // get dimensions
    constexpr std::array fact{0, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800};
    constexpr size_t total{fact[10]/fact[10-LENGTH]};
    static constexpr char int2char{'0'};

    std::vector<Number> ret;
    ret.resize(total);

    std::array<bool, 10> used{};
    std::fill_n(used.begin()+10-LENGTH, LENGTH, 1);
    const std::string digits{"0123456789"};

    std::string used_digits;
    used_digits.resize(LENGTH);
    auto cur_nb = ret.begin();
    constexpr auto perms{fact[LENGTH]};
    do
    {
      std::copy_if(digits.begin(), digits.end(), used_digits.begin(),
                   [&](auto digit){return used[digit-int2char];});

      for(int perm = 0; perm < perms; ++perm)
      {
        cur_nb->update(used_digits);
        cur_nb++;
        std::next_permutation(used_digits.begin(), used_digits.end());
      }
    } while(std::next_permutation(used.begin(), used.end()));

    return ret;
  }

  inline bool isValid() const
  {
    for(uint i = 0; i < LENGTH-1; ++i)
    {
      for(uint j = i+1; j < LENGTH; ++j)
      {
        if(digits_[i] == digits_[j])
          return false;
      }
    }
    return true;
  }
};
}
}

inline std::ostream& operator<<(std::ostream &os, const duels::bulls_cows::Number &n)
{
  os << n.digits();
  return os;
}


#endif
