#include <duels/gorillas/game.h>

using namespace duels::gorillas;

#include <duels/gorillas/msg.h>
#include <cmath> // for sqrt and atan2

using namespace duels::gorillas;


class GorillAI {
private:
  bool firstTurn = true; // Tracks if it's the first turn
  float adaptiveGainAngle = 0.05; // Adaptive adjustment rate for angle
  float adaptiveGainVelocity = 0.05; // Adaptive adjustment rate for velocity
  float previousErrorX = 0.0; // Previous error in x-direction
  float previousErrorY = 0.0; // Previous error in y-direction

public:
  Input computeFrom(const Feedback &feedback) {
    Input input;

	if (firstTurn) {
	  // First turn: Make an educated guess
	  input.angle = 45.0;  // A balanced angle for many scenarios
	  input.vel = 35.0;    // Estimated velocity for a mid-range throw
	  firstTurn = false;   // Update the first-turn flag
	} else {
	  // Adaptive logic for subsequent turns
	  float errorX = feedback.banana.x - feedback.opponent.x;
	  float errorY = feedback.banana.y - feedback.opponent.y;

	  // Adjust angle and velocity based on feedback errors
	  input.angle += errorX * adaptiveGainAngle;
	  input.vel += errorY * adaptiveGainVelocity;

	  // Incorporate wind adjustment for fine-tuning
	  input.vel += feedback.wind * 0.1;

	  // Update previous errors for future comparisons
	  previousErrorX = errorX;
	  previousErrorY = errorY;
	}

    return input; // Return the calculated inputs
  }

  // Method to adjust adaptive gains dynamically if needed
  void setAdaptiveGains(float gainAngle, float gainVelocity) {
    adaptiveGainAngle = gainAngle;
    adaptiveGainVelocity = gainVelocity;
  }
};

int main(int argc, char** argv)
{
  Game game(argc, argv, "Your name here", 3);   // difficulty from 0 to 3

  Input input;
  Feedback feedback;
  const auto timeout = game.timeout_ms();

  GorillAI gorillaAI;

  while(game.get(feedback))
  {
    // write input in less than timeout
    input.angle = 60;
    input.vel = 50;

    game.send(gorillaAI.computeFrom(feedback));


  }
}
