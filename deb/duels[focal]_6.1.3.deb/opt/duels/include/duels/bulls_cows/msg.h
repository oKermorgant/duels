// generated from bulls_cows.yaml -- editing this file by hand is not recommended
#ifndef BULLS_COWS_MSG_H
#define BULLS_COWS_MSG_H
#include <sstream>
#include <duels/game_state.h>

namespace duels {
namespace bulls_cows {

struct InitDisplay
{
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    return ss.str();
  }
};

struct Input
{
  int guess;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "guess: " << guess;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    guess = node["guess"].as<int>();
  }
};

struct Feedback
{
  int bulls;
  int cows;
  State __state;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "bulls: " << bulls;
    ss << "\ncows: " << cows;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    bulls = node["bulls"].as<int>();
    cows = node["cows"].as<int>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  int guess1;
  int guess2;
 
  std::string serialize(State state) const 
  {
    std::stringstream ss;
    ss << "state: " << state;
    ss << "\nguess1: " << guess1;
    ss << "\nguess2: " << guess2;
    return ss.str();
  }
};

}}


#endif