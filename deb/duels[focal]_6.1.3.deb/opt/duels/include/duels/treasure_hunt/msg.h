// generated from treasure_hunt.yaml -- editing this file by hand is not recommended
#ifndef TREASURE_HUNT_MSG_H
#define TREASURE_HUNT_MSG_H
#include <sstream>
#include <duels/game_state.h>
#include <duels/utils/pose2d.h>
#include <duels/utils/vector2d.h>

namespace duels {
namespace treasure_hunt {

// utility structures
struct Scan
{
  int x;
  int y;
  bool occupied;
  inline bool operator==(const Scan &other) const
  {
    return x == other.x && y == other.y && occupied == other.occupied;
  }
  inline friend std::ostream& operator<<(std::ostream& ss, const Scan &scan)
  {
    ss << "{";
    ss << "x: " << scan.x << ',';
    ss << "y: " << scan.y << ',';
    ss << "occupied: " << scan.occupied << "}";
    return ss;
  }
};
enum class Action{TURN_LEFT,TURN_RIGHT,MOVE,SONAR};


// core game messages

struct InitDisplay
{
  duels::Pose2D pose1;
  duels::Pose2D pose2;
  duels::Vector2D<int> treasure;
  std::vector<duels::Vector2D<int>> obs;
  int height;
  int width;
 
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    ss << "\npose1: " << pose1;
    ss << "\npose2: " << pose2;
    ss << "\ntreasure: " << treasure;
    ss << "\nobs: " << obs;
    ss << "\nheight: " << height;
    ss << "\nwidth: " << width;
    return ss.str();
  }
};

struct Input
{
  Action action;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "action: " << action;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    action = node["action"].as<Action>();
  }
};

struct Feedback
{
  duels::Pose2D pose;
  std::vector<Scan> scan;
  double treasure_distance;
  State __state;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "pose: " << pose;
    ss << "\nscan: " << scan;
    ss << "\ntreasure_distance: " << treasure_distance;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    pose = node["pose"].as<duels::Pose2D>();
    scan = node["scan"].as<std::vector<Scan>>();
    treasure_distance = node["treasure_distance"].as<double>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  duels::Pose2D pose1;
  duels::Pose2D pose2;
  std::vector<duels::Vector2D<int>> scans;
 
  std::string serialize(State state) const 
  {
    std::stringstream ss;
    ss << "state: " << state;
    ss << "\npose1: " << pose1;
    ss << "\npose2: " << pose2;
    ss << "\nscans: " << scans;
    return ss.str();
  }
};

}}

namespace YAML
{
template<>
struct convert<duels::treasure_hunt::Scan> 
{
  static bool decode(Node const& node, duels::treasure_hunt::Scan & rhs)
  {
    rhs.x = node["x"].as<int>();
    rhs.y = node["y"].as<int>();
    rhs.occupied = node["occupied"].as<short>();
    return true;
  }
};
}

#endif