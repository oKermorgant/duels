// generated from gorillas.yaml -- editing this file by hand is not recommended
#ifndef GORILLAS_MSG_H
#define GORILLAS_MSG_H
#include <sstream>
#include <duels/game_state.h>
#include <duels/utils/vector2d.h>

namespace duels {
namespace gorillas {

// utility structures
struct Banana
{
  float x;
  float y;
  inline bool operator==(const Banana &other) const
  {
    return x == other.x && y == other.y;
  }
  inline friend std::ostream& operator<<(std::ostream& ss, const Banana &banana)
  {
    ss << "{";
    ss << "x: " << banana.x << ',';
    ss << "y: " << banana.y << "}";
    return ss;
  }
};


// core game messages

struct InitDisplay
{
  duels::Vector2D<int> gor1;
  duels::Vector2D<int> gor2;
  std::array<int, 640> yb;
  int radius;
 
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    ss << "\ngor1: " << gor1;
    ss << "\ngor2: " << gor2;
    ss << "\nyb: " << yb;
    ss << "\nradius: " << radius;
    return ss.str();
  }
};

struct Input
{
  float angle;
  float vel;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "angle: " << angle;
    ss << "\nvel: " << vel;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    angle = node["angle"].as<float>();
    vel = node["vel"].as<float>();
  }
};

struct Feedback
{
  duels::Vector2D<int> me;
  duels::Vector2D<int> opponent;
  Banana banana;
  float wind;
  std::array<int, 640> building;
  State __state;
 
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "me: " << me;
    ss << "\nopponent: " << opponent;
    ss << "\nbanana: " << banana;
    ss << "\nwind: " << wind;
    ss << "\nbuilding: " << building;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    me = node["me"].as<duels::Vector2D<int>>();
    opponent = node["opponent"].as<duels::Vector2D<int>>();
    banana = node["banana"].as<Banana>();
    wind = node["wind"].as<float>();
    building = node["building"].as<std::array<int, 640>>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  Banana banana;
  bool hit;
  float wind;
 
  std::string serialize(State state) const 
  {
    std::stringstream ss;
    ss << "state: " << state;
    ss << "\nbanana: " << banana;
    ss << "\nhit: " << hit;
    ss << "\nwind: " << wind;
    return ss.str();
  }
};

}}

namespace YAML
{
template<>
struct convert<duels::gorillas::Banana> 
{
  static bool decode(Node const& node, duels::gorillas::Banana & rhs)
  {
    rhs.x = node["x"].as<float>();
    rhs.y = node["y"].as<float>();
    return true;
  }
};
}

#endif