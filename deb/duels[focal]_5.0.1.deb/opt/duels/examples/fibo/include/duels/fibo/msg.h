// generated from fibo.yaml -- editing this file by hand is not recommended
#ifndef FIBO_MSG_H
#define FIBO_MSG_H
#include <sstream>
#include <duels/game_state.h>
namespace duels {
namespace fibo {

struct InitDisplay
{
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    return ss.str();
  }
};

struct Input
{
  int s;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "s: " << s;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    s = node["s"].as<int>();
  }
};

struct Feedback
{
  int a; int b; State __state;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "a: " << a;
    ss << "\nb: " << b;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    a = node["a"].as<int>();
    b = node["b"].as<int>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  std::string serialize(Result result) const 
  {
    std::stringstream ss;
    ss << "result: " << result;
    return ss.str();
  }
};

}}
#endif