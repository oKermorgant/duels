#ifndef FIBOAI_H
#define FIBOAI_H

#include <duels/player.h>
#include <duels/fibo/msg.h>
#include <iostream>
#include <thread>

namespace duels {
namespace fibo {
class FiboAI : public duels::Player<Input, Feedback>
{
public:
  FiboAI(int difficulty = 1) : difficulty(difficulty) {}

  void updateInput()
  {
    input.s = feedback.a + feedback.b;

    std::cerr << "Bot [" << difficulty << "] : " <<
                 input.s << "=" << feedback.a <<"+"<< feedback.b<<std::endl;

  }

private:
  int difficulty = 1;

};

}
}

#endif // FIBOAI_H
