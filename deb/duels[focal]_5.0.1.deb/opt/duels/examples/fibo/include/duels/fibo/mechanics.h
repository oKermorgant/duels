#ifndef MECHANICS_H
#define MECHANICS_H

#include <duels/fibo/msg.h>

using duels::State;
using namespace duels::fibo;

class FiboMechanics
{
public:
  FiboMechanics() {}
  InitDisplay initGame() {return {};}
  void informPlayer(Feedback &feedback, [[maybe_unused]] bool player_1_turn)
  {
    feedback.a = a;
    feedback.b = b;
  }

  bool registerInput(const Input &input, [[maybe_unused]] bool player_1_turn)
  {
    if(input.s != a+b)
      return false;
    a = b;
    b = input.s;
    return true;
  }

private:
  int a = 0;
  int b = 1;

};

#endif // MECHANICS_H