#include <duels/fibo/fibo_ai.h>

FiboAI::FiboAI()
{

}
