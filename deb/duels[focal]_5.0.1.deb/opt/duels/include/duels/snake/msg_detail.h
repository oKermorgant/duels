// generated from snake.yaml -- editing this file by hand is not recommended
inline std::ostream& operator<<(std::ostream& ss, const duels::snake::Snake &snake)
{
  ss << "{";
  ss << "head: " << snake.head << ',';
  ss << "body: " << snake.body << "}";
  return ss;
}

namespace YAML
{
template<>
struct convert<duels::snake::Snake> 
{
  static bool decode(Node const& node, duels::snake::Snake & rhs)
  {
    rhs.head = node["head"].as<duels::Pose2D>();
    rhs.body = node["body"].as<std::vector<duels::Position2D>>();
    return true;
  }
};
}