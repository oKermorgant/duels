// generated from treasure_hunt.yaml -- editing this file by hand is not recommended
inline std::ostream& operator<<(std::ostream& ss, const duels::treasure_hunt::Scan &scan)
{
  ss << "{";
  ss << "x: " << scan.x << ',';
  ss << "y: " << scan.y << ',';
  ss << "occupied: " << scan.occupied << "}";
  return ss;
}

namespace YAML
{
template<>
struct convert<duels::treasure_hunt::Scan> 
{
  static bool decode(Node const& node, duels::treasure_hunt::Scan & rhs)
  {
    rhs.x = node["x"].as<int>();
    rhs.y = node["y"].as<int>();
    rhs.occupied = node["occupied"].as<short>();
    return true;
  }
};
}