// generated from treasure_hunt.yaml -- editing this file by hand is not recommended
#ifndef TREASURE_HUNT_MSG_H
#define TREASURE_HUNT_MSG_H
#include <sstream>
#include <duels/game_state.h>
#include <duels/msg/pose2d.h>
#include <duels/msg/position2d.h>
namespace duels {
namespace treasure_hunt {

// utility structures
struct Scan
{
  int x;int y;bool occupied;
  inline bool operator==(const Scan &other) const
  {
    return x == other.x && y == other.y && occupied == other.occupied;
  }
};
enum class Action{TURN_LEFT,TURN_RIGHT,MOVE,SONAR};
}}

//detail on how to stream these structures
#include "msg_detail.h"

// core game messages
namespace duels {
namespace treasure_hunt {

struct InitDisplay
{
  duels::Pose2D pose1; duels::Pose2D pose2; duels::Position2D treasure; std::vector<duels::Position2D> obs; int height; int width;
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    ss << "\npose1: " << pose1;
    ss << "\npose2: " << pose2;
    ss << "\ntreasure: " << treasure;
    ss << "\nobs: " << obs;
    ss << "\nheight: " << height;
    ss << "\nwidth: " << width;
    return ss.str();
  }
};

struct Input
{
  Action action;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "action: " << action;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    action = node["action"].as<Action>();
  }
};

struct Feedback
{
  duels::Pose2D pose; std::vector<Scan> scan; float treasure_distance; State __state;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "pose: " << pose;
    ss << "\nscan: " << scan;
    ss << "\ntreasure_distance: " << treasure_distance;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    pose = node["pose"].as<duels::Pose2D>();
    scan = node["scan"].as<std::vector<Scan>>();
    treasure_distance = node["treasure_distance"].as<float>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  duels::Pose2D pose1; duels::Pose2D pose2; std::vector<duels::Position2D> scans;
  std::string serialize(Result result) const 
  {
    std::stringstream ss;
    ss << "result: " << result;
    ss << "\npose1: " << pose1;
    ss << "\npose2: " << pose2;
    ss << "\nscans: " << scans;
    return ss.str();
  }
};

}}
#endif