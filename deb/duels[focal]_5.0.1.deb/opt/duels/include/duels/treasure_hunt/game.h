#ifndef TREASURE_HUNT_GAME_H
#define TREASURE_HUNT_GAME_H
#include <duels/client.h>
#include <duels/treasure_hunt/msg.h>
#include <sstream>
namespace duels {
namespace treasure_hunt {
class Game: public duels::Client<Input, Feedback>
{
public:
  /// to play as player 1 against some AI
  Game(int argc, char** argv, std::string name, int difficulty)
    : Game(argc, argv, name, difficulty, "localhost") {}
  /// to play as player 2 against some AI
  Game(int argc, char** argv, int difficulty, std::string name)
    : Game(argc, argv, name, -difficulty, "localhost") {}
private:
  Game(int argc, char** argv, std::string name, int difficulty, std::string ip)
      : duels::Client<Input, Feedback>(
      argc, argv, 100, 800, name, difficulty, ip, "treasure_hunt") {}
};
}
}
#endif