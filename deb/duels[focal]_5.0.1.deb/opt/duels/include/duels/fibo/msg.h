// generated from fibo.yaml -- editing this file by hand is not recommended
#ifndef FIBO_MSG_H
#define FIBO_MSG_H
#include <sstream>
#include <duels/game_state.h>
#include <duels/stream_overloads.h>
namespace duels {
namespace fibo {

struct InitDisplay
{
  std::string toYAMLString(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    return ss.str();
  }
};

struct Input
{
  int s;
  std::string toString() const 
  {
    std::stringstream ss;
    ss << "s: " << s;
    return ss.str();
  }
};

struct Feedback
{
  int a; int b;
  std::string toString() const 
  {
    std::stringstream ss;
    ss << "a: " << a;
    ss << "\nb: " << b;
    return ss.str();
  }
  State __state;
};

struct Display
{
  std::string toYAMLString(Result result) const 
  {
    std::stringstream ss;
    ss << "result: " << result;
    return ss.str();
  }
};

}}
#endif