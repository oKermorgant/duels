#ifndef DUELS_POSE2D_H
#define DUELS_POSE2D_H

#include <duels/utils/vector2d.h>
#include <duels/msg/orientation.h>
#include <duels/stream_overloads.h>

/// helper class to handle 2D pose in grids (x,y + orientation)

namespace duels
{

struct Pose2D : public Vector2D<int>
{
  Orientation orientation;

  Pose2D(int x = 0, int y = 0, Orientation orientation = Orientation::UP)
    : Vector2D<int> (x,y), orientation{orientation}
  {}

  Pose2D(const Vector2D<int> &xy, Orientation orientation = Orientation::UP)
    : Vector2D<int> (xy), orientation{orientation}
  {}

  inline friend std::ostream& operator<<(std::ostream& ss, const Pose2D &pose)
  {
      ss << "{";
      ss << "x: " << pose.x << ',';
      ss << "y: " << pose.y << ',';
      ss << "orientation: " << pose.orientation;
      return ss << '}';
  }

  inline bool operator==(const Pose2D &other) const
  {
    return this->x == other.x && this->y == other.y && orientation == other.orientation;
  }

  inline bool operator==(const Vector2D<int> &other) const
  {
    return this->x == other.x && this->y == other.y;
  }

  inline Pose2D fwd(int dx = 1) const
  {
    return {*this + orientation.fwd(dx), orientation};
  }
  inline Pose2D left(int dx = 1) const
  {
    const Orientation next{orientation.toLeft()};
    return {*this + next.fwd(dx), next};
  }
  inline Pose2D right(int dx = 1) const
  {
    const Orientation next{orientation.toRight()};
    return {*this + next.fwd(dx), next};
  }

  inline void move(int dx = 1)
  {
    *this += orientation.fwd(dx);
  }
};
}

namespace YAML
{
template<>
struct convert<duels::Pose2D>
{
  static bool decode(Node const& node, duels::Pose2D & rhs)
  {
    rhs.x = node["x"].as<int>();
    rhs.y = node["y"].as<int>();
    rhs.orientation = node["orientation"].as<duels::Orientation>();
    return true;
  }
};
}

#endif // DUELS_POSE2D_H
