#ifndef DUELS_ORIENTATION_H
#define DUELS_ORIENTATION_H

#include <duels/utils/vector2d.h>
#include <duels/stream_overloads.h>

/// helper class to handle basic orientations

namespace duels
{

struct Orientation
{
  enum class Direction:short{RIGHT,UP,LEFT,DOWN};
  Direction orientation;
public:
  constexpr static auto RIGHT{Direction::RIGHT};
  constexpr static auto UP{Direction::UP};
  constexpr static auto LEFT{Direction::LEFT};
  constexpr static auto DOWN{Direction::DOWN};

  Orientation(const Direction &orientation = Orientation::LEFT) : orientation{orientation} {}
  Orientation(const Orientation &orientation) = default;

  inline friend std::ostream& operator<<(std::ostream& ss, const Orientation &orientation)
  {
    return ss << orientation.orientation;
  }

  inline bool operator==(const Direction &orientation) const
  {
    return this->orientation == orientation;
  }
  inline bool operator==(const Orientation &other) const
  {
    return this->orientation == other.orientation;
  }
  inline Orientation operator=(const Direction &orientation)
  {
    this->orientation = orientation;
    return *this;
  }

  inline Direction toLeft() const
  {
    if(orientation == RIGHT)
      return UP;
    if(orientation == UP)
      return LEFT;
    if(orientation == LEFT)
      return DOWN;
    return RIGHT;
  }

  inline Direction toRight() const
  {
    if(orientation == RIGHT)
      return DOWN;
    if(orientation == UP)
      return RIGHT;
    if(orientation == LEFT)
      return UP;
    return LEFT;
  }

  inline void turnLeft()
  {
    orientation = toLeft();
  }

  inline void turnRight()
  {
    orientation = toRight();
  }

  template<typename Numeric = int>
  inline duels::Vector2D<Numeric> fwd(Numeric dx = 1) const
  {
    if(orientation == RIGHT)
      return {dx,0};
    if(orientation == UP)
      return {0,-dx};
    if(orientation == LEFT)
      return {-dx,0};
    return {0,dx};
  }

  inline float angle() const
  {
    return -static_cast<short>(orientation) * M_PI_2;
  }
};
}

namespace YAML
{
template<>
struct convert<duels::Orientation>
{
  static bool decode(Node const& node, duels::Orientation & rhs)
  {
    rhs = static_cast<duels::Orientation::Direction>(node.template as<short>());
    return true;
  }
};
}

#endif // DUELS_ORIENTATION_H
