#ifndef DUELS_POSITION2D_H
#define DUELS_POSITION2D_H

#include <duels/utils/vector2d.h>
#include <duels/stream_overloads.h>

/// helper class to handle 2D position in grids

namespace duels
{
using Position2D = Vector2D<int>;
}

inline std::ostream& operator<<(std::ostream& ss, const duels::Position2D &position)
{
    ss << "{";
    ss << "x: " << position.x << ',';
    ss << "y: " << position.y << '}';
    return ss;
}

namespace YAML
{
template<>
struct convert<duels::Position2D>
{
  static bool decode(Node const& node, duels::Position2D & rhs)
  {
    rhs.x = node["x"].as<int>();
    rhs.y = node["y"].as<int>();
    return true;
  }
};
}

#endif // DUELS_POSITION2D_H
