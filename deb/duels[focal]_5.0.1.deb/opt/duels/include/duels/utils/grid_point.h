#ifndef DUELS_GRID_POINT_H
#define DUELS_GRID_POINT_H

#include <duels/utils/vector2d.h>
#include <duels/utils/grid.h>
#include <vector>
#include <memory>

// A 2D point on a grid that is able to generate its neighboors for A*

namespace duels
{

class GridPoint : public Vector2D<int>
{
    using GridPointPtr = std::unique_ptr<GridPoint>;

public:

  GridPoint(int _x=0, int _y=0) : Vector2D<int>(_x, _y) {}

  static void setMap(Grid & _grid, bool _use_manhattan = true)
  {
      grid = &_grid;
      use_manhattan = _use_manhattan;
  }

  float h(const Vector2D<int>& other) const
  {
    return static_cast<float>(distance(other, use_manhattan));
  }

  virtual float distToParent() const {return 1.f;}

  bool isGoal(const Vector2D<int>& goal) const
  {
    return x == goal.x && y == goal.y;
  }

  std::vector<GridPointPtr> children() const
  {
    std::vector<GridPointPtr> out;
    for(auto [dx, dy]: std::vector<std::pair<int,int>>({{-1,0},{1,0},{0,-1},{0,1}}))
    {
      if(grid->isFree(x + dx, y + dy))
        out.push_back(std::make_unique<GridPoint>(x + dx, y + dy));
    }
    return out;
  }

protected:
  // grid points share the same grid
  static inline Grid *grid;
  static inline bool use_manhattan;
};

}

#endif // DUELS_GRID_POINT_H
