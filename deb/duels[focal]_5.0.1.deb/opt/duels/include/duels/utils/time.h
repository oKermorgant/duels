#ifndef TIMEUTILS_H
#define TIMEME__UTILS_H

#include <chrono>

namespace duels
{
using Clock = std::chrono::high_resolution_clock;

inline int milliseconds_since(const Clock::time_point &start)
{
  return std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count();
}
inline int microseconds_since(const Clock::time_point &start)
{
  return std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
}
}

#endif

