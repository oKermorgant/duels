// generated from gorillas.yaml -- editing this file by hand is not recommended
inline std::ostream& operator<<(std::ostream& ss, const duels::gorillas::Banana &banana)
{
  ss << "{";
  ss << "x: " << banana.x << ',';
  ss << "y: " << banana.y << "}";
  return ss;
}

namespace YAML
{
template<>
struct convert<duels::gorillas::Banana> 
{
  static bool decode(Node const& node, duels::gorillas::Banana & rhs)
  {
    rhs.x = node["x"].as<float>();
    rhs.y = node["y"].as<float>();
    return true;
  }
};
}