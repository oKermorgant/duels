// generated from gorillas.yaml -- editing this file by hand is not recommended
#ifndef GORILLAS_MSG_H
#define GORILLAS_MSG_H
#include <sstream>
#include <duels/game_state.h>
#include <duels/msg/position2d.h>
namespace duels {
namespace gorillas {

// utility structures
struct Banana
{
  float x;float y;
  inline bool operator==(const Banana &other) const
  {
    return x == other.x && y == other.y;
  }
};
}}

//detail on how to stream these structures
#include "msg_detail.h"

// core game messages
namespace duels {
namespace gorillas {

struct InitDisplay
{
  duels::Position2D gor1; duels::Position2D gor2; std::array<int, 640> yb; int radius;
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    ss << "\ngor1: " << gor1;
    ss << "\ngor2: " << gor2;
    ss << "\nyb: " << yb;
    ss << "\nradius: " << radius;
    return ss.str();
  }
};

struct Input
{
  float angle; float vel;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "angle: " << angle;
    ss << "\nvel: " << vel;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    angle = node["angle"].as<float>();
    vel = node["vel"].as<float>();
  }
};

struct Feedback
{
  duels::Position2D me; duels::Position2D opponent; Banana banana; float wind; std::array<int, 640> building; State __state;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "me: " << me;
    ss << "\nopponent: " << opponent;
    ss << "\nbanana: " << banana;
    ss << "\nwind: " << wind;
    ss << "\nbuilding: " << building;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    me = node["me"].as<duels::Position2D>();
    opponent = node["opponent"].as<duels::Position2D>();
    banana = node["banana"].as<Banana>();
    wind = node["wind"].as<float>();
    building = node["building"].as<std::array<int, 640>>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  Banana banana; bool hit; float wind;
  std::string serialize(Result result) const 
  {
    std::stringstream ss;
    ss << "result: " << result;
    ss << "\nbanana: " << banana;
    ss << "\nhit: " << hit;
    ss << "\nwind: " << wind;
    return ss.str();
  }
};

}}
#endif