#ifndef GORILLAS_GAME_H
#define GORILLAS_GAME_H
#include <duels/client.h>
#include <duels/gorillas/msg.h>
#include <sstream>
namespace duels {
namespace gorillas {
class Game: public duels::Client<Input, Feedback>
{
public:
  /// to play as player 1 against some AI
  Game(int argc, char** argv, std::string name, int difficulty)
    : Game(argc, argv, name, difficulty, "localhost") {}
  /// to play as player 2 against some AI
  Game(int argc, char** argv, int difficulty, std::string name)
    : Game(argc, argv, name, -difficulty, "localhost") {}
private:
  Game(int argc, char** argv, std::string name, int difficulty, std::string ip)
      : duels::Client<Input, Feedback>(
      argc, argv, 1000, 15000, name, difficulty, ip, "gorillas") {}
};
}
}
#endif