#include <algorithm>
#include <vector>
#include <iostream>

#include <duels/game_state.h>
#include <duels/utils/rand_utils.h>

/* This function uses alpha-beta algorithm for a given game configuration
 */

namespace duels
{

template<class T>
int alpha_beta(T& game, int alpha, int beta, unsigned int max_recur, unsigned int recur = 0)
{
  if(recur == 0)
  {
    auto choices = decltype(game.availableMoves()){};
    int val;
    for(const auto &move: game.availableMoves())
    {
      game.makeMove(move);
      val = -alpha_beta(game, alpha, beta, max_recur, 1);
      //std::cout << "Move " << move << " -> score = " << val << std::endl;
      game.cancelMove(move);
      if(val > alpha)
      {
        alpha = val;
        choices = {move};
      }
      else if(val == alpha)
        choices.push_back(move);
    }
    unsigned int idx = fastrand(choices.size());
    //std::cout << "Making move " << choices[idx] << std::endl;
    game.makeMove(choices[idx]);
    return 0;
  }

  // check for end of game
  Result result = game.result();
  if(result == Result::P1_WINS || result == Result::P2_WINS)
    return -100+recur;

  // what to return
  if(result == Result::DRAW || recur == max_recur)
    return recur;

  // build new moves
  int best = -5000;

  for(auto move: game.availableMoves())
  {
    game.makeMove(move);
    auto val = -alpha_beta(game, -beta, -alpha, max_recur, recur+1);
    game.cancelMove(move);
    if(val > best)
    {
      best = val;
      if(best > alpha)
      {
        alpha = best;
        if(alpha > beta)
          return best;
      }
    }
  }
  return best;
}
}
