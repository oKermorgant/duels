// generated from connect4.yaml -- editing this file by hand is not recommended
inline std::ostream& operator<<(std::ostream& ss, const duels::connect4::Cell &cell)
{
  ss << "{";
  ss << "row: " << cell.row << ',';
  ss << "column: " << cell.column << ',';
  ss << "token: " << cell.token << "}";
  return ss;
}

namespace YAML
{
template<>
struct convert<duels::connect4::Cell> 
{
  static bool decode(Node const& node, duels::connect4::Cell & rhs)
  {
    rhs.row = node["row"].as<short>();
    rhs.column = node["column"].as<short>();
    rhs.token = node["token"].as<duels::connect4::Token>();
    return true;
  }
};
}