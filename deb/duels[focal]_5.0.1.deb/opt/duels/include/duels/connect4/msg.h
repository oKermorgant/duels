// generated from connect4.yaml -- editing this file by hand is not recommended
#ifndef CONNECT4_MSG_H
#define CONNECT4_MSG_H
#include <sstream>
#include <duels/game_state.h>
namespace duels {
namespace connect4 {

// utility structures
enum class Token{PLAYER1,PLAYER2};
struct Cell
{
  short row;short column;Token token;
  inline bool operator==(const Cell &other) const
  {
    return row == other.row && column == other.column && token == other.token;
  }
};
}}

//detail on how to stream these structures
#include "msg_detail.h"

// core game messages
namespace duels {
namespace connect4 {

struct InitDisplay
{
  short rows; short columns;
  std::string serialize(std::string name1, std::string name2) const 
  {
    std::stringstream ss;
    ss << "name1: " << name1;
    ss << "\nname2: " << name2;
    ss << "\nrows: " << rows;
    ss << "\ncolumns: " << columns;
    return ss.str();
  }
};

struct Input
{
  short column;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "column: " << column;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    column = node["column"].as<short>();
  }
};

struct Feedback
{
  std::vector<Cell> cells; State __state;
  std::string serialize() const 
  {
    std::stringstream ss;
    ss << "cells: " << cells;
    ss << "\n__state: " << __state;
    return ss.str();
  }
  void deserialize(const std::string &yaml)
  {
    const auto node{YAML::Load(yaml)};
    cells = node["cells"].as<std::vector<Cell>>();
    __state = node["__state"].as<State>();
  }
};

struct Display
{
  Cell last_cell;
  std::string serialize(Result result) const 
  {
    std::stringstream ss;
    ss << "result: " << result;
    ss << "\nlast_cell: " << last_cell;
    return ss.str();
  }
};

}}
#endif