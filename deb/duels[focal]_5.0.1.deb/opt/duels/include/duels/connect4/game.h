#ifndef CONNECT4_GAME_H
#define CONNECT4_GAME_H
#include <duels/client.h>
#include <duels/connect4/msg.h>
#include <sstream>
namespace duels {
namespace connect4 {
class Game: public duels::Client<Input, Feedback>
{
public:
  /// to play as player 1 against some AI
  Game(int argc, char** argv, std::string name, int difficulty)
    : Game(argc, argv, name, difficulty, "localhost") {}
  /// to play as player 2 against some AI
  Game(int argc, char** argv, int difficulty, std::string name)
    : Game(argc, argv, name, -difficulty, "localhost") {}
private:
  Game(int argc, char** argv, std::string name, int difficulty, std::string ip)
      : duels::Client<Input, Feedback>(
      argc, argv, 1000, 4000, name, difficulty, ip, "connect4") {}
};
}
}
#endif